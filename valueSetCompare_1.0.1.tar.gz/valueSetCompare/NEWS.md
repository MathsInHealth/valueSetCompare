# valueSetCompare 1.0.1

* Added a `NEWS.md` file to track changes to the package.
* Updated examples to reflect changes in the `eq5dsuite` package, ensuring compatibility with the latest version.